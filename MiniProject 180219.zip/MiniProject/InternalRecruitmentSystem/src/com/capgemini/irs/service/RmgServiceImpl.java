package com.capgemini.irs.service;

import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

import com.capegemini.irs.bean.ProjectBean;
import com.capegemini.irs.bean.ReqEmployee;
import com.capegemini.irs.bean.RequisitionBean;
import com.capgemini.irs.dao.IRmgDao;
import com.capgemini.irs.dao.RmgDaoImpl;

public class RmgServiceImpl implements IRmgService {
IRmgDao rmDao=null;
	@Override
	public int raiseRequisition(RequisitionBean rbean) throws IOException {
		rmDao=new RmgDaoImpl();
		return rmDao.raiseRequisition(rbean);
	}
	
	@Override
	public List<ReqEmployee> retrieveDetails(String reqId) throws IOException {
		rmDao=new RmgDaoImpl();
		return rmDao.retrieveDetails(reqId);
		
		
	}

	@Override
	public boolean selectEmployee(String eid, String reqId) throws IOException {
		rmDao=new RmgDaoImpl();
		boolean b=rmDao.getEmployeeDetails(eid,reqId);
		return b;
	}

	@Override
	public boolean rejectRes(String empId, String reqId1) throws IOException {
		rmDao=new RmgDaoImpl();
		boolean b1=rmDao.rejectRes(empId, reqId1);
		return b1;
	}

	@Override
	public List<ProjectBean> getProjectDetails(String rid) throws IOException {
		rmDao=new RmgDaoImpl();
		return rmDao.getProjectDetails(rid);
	}

	@Override
	public List<RequisitionBean> getRequisitionByStatus(String rmid1) throws IOException {
		rmDao=new RmgDaoImpl();
		return rmDao.getRequisitionByStatus(rmid1);
	}

	@Override
	public List<RequisitionBean> getRequisitionByStatusClosed(String rmid2) throws IOException {
		rmDao=new RmgDaoImpl();
		return rmDao.getRequisitionByStatusClosed(rmid2);
	}

}
