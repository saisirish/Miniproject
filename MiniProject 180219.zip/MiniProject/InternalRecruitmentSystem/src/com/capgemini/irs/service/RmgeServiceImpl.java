package com.capgemini.irs.service;

import java.io.IOException;
import java.util.List;

import com.capegemini.irs.bean.EmployeeBean;
import com.capegemini.irs.bean.RequisitionBean;
import com.capgemini.irs.dao.RmgeDao;
import com.capgemini.irs.dao.RmgeDaoImpl;

public class RmgeServiceImpl implements IRmgeService {
RmgeDao dao=null;
	@Override
	public RequisitionBean getParticularRequisition(String rid) throws IOException {
		dao=new RmgeDaoImpl();
		return dao.getParticularRequisition(rid);
	}
	@Override
	public List<EmployeeBean> getEmployeeDetails(RequisitionBean rbean) throws IOException {
		dao=new RmgeDaoImpl();
		return dao.getEmployeeDetails(rbean);
	}
	@Override
	public List<RequisitionBean> getAllRequisition() throws IOException {
		dao=new RmgeDaoImpl();
		return dao.getAllRequisition();
	}
	@Override
	public List<RequisitionBean> getPendingRequisition(String rmid3) throws IOException {
		dao=new RmgeDaoImpl();
		return dao.getPendingRequisition(rmid3);
		
	}
	@Override
	public List<RequisitionBean> getClosedRequisition(String rmid4) throws IOException 
	{
		dao=new RmgeDaoImpl();
		return dao.getClosedRequisition(rmid4);
	}
	@Override
	public int storeEmployeeDetails(List<EmployeeBean> employeeList, RequisitionBean rbean) throws IOException {
		dao=new RmgeDaoImpl();
		return dao.storeEmployeeDetails(employeeList, rbean);
	}
	
}
