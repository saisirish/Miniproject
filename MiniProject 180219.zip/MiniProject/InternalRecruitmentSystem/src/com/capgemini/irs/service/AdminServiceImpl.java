package com.capgemini.irs.service;

import java.io.IOException;
import java.util.List;

import com.capegemini.irs.bean.AdminBean;
import com.capgemini.irs.dao.AdminDao;
import com.capgemini.irs.dao.IAdminDao;

public class AdminServiceImpl implements IAdminService{
IAdminDao dao=null;
	@Override
	public int addUser(AdminBean admin) throws IOException {
		dao=new AdminDao();
		return dao.addUsers(admin);
		
		
		
	}
	@Override
	public List<AdminBean> retriveAllUsers() throws IOException {
		dao=new AdminDao();
		return dao.retriveAllUsers();
	}
	@Override
	public int deleteUsers(String user1) throws IOException {
		dao=new AdminDao();
		return dao.deleteUsers(user1);
	}

}
