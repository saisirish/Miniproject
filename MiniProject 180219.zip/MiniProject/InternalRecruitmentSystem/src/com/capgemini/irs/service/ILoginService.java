package com.capgemini.irs.service;

import java.io.IOException;

import com.capegemini.irs.bean.AdminBean;

public interface ILoginService{

	AdminBean checkUserDetails(AdminBean admin) throws IOException;

}
