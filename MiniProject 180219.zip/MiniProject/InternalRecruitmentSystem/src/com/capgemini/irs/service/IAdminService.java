package com.capgemini.irs.service;

import java.io.IOException;
import java.util.List;

import com.capegemini.irs.bean.AdminBean;
import com.capegemini.irs.bean.RequisitionBean;

public interface IAdminService {

	int addUser(AdminBean admin) throws IOException;

	List<AdminBean> retriveAllUsers() throws IOException;

	int deleteUsers(String user1) throws IOException;

	

}
