package com.capgemini.irs.ui;

import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import com.capgemini.irs.service.IAdminService;
import com.capegemini.irs.bean.AdminBean;
import com.capegemini.irs.bean.EmployeeBean;
import com.capegemini.irs.bean.ProjectBean;
import com.capegemini.irs.bean.ReqEmployee;
import com.capegemini.irs.bean.RequisitionBean;
import com.capgemini.irs.service.AdminServiceImpl;
import com.capgemini.irs.service.ILoginService;
import com.capgemini.irs.service.IRmgService;
import com.capgemini.irs.service.IRmgeService;
import com.capgemini.irs.service.LoginService;
import com.capgemini.irs.service.RmgServiceImpl;
import com.capgemini.irs.service.RmgeServiceImpl;

public class Client {
static	IAdminService service=null;
static IRmgService rmService=null;
static IRmgeService rmgeService=null;
static AdminBean admin=null;
static  String fuser=null;
public static void main(String[] args) throws IOException, SQLException {
	Scanner sc = new Scanner(System.in);
	 admin=new AdminBean();
	List<AdminBean> userList=null;
	RequisitionBean rbean=null;
	int userStatus=0;
	int deleteStatus=0;
	System.out.println("Enter UserName: ");
	String userName = sc.next();
	admin.setUserId(userName);
	System.out.println("Enter Password: ");
	String password = sc.next();
	admin.setPassword(password);
	System.out.println("Enter role:");
	String role = sc.next();
	admin.setRole(role);
	//admin = new AdminBean(userName, password, role);
	//AdminBean admin1 = new AdminBean();
	//AdminBean admin1;
	// admin1=checkLoginDetails(admin);
	//  System.out.println("entered"+admin1.getUserId());
	  
	  //System.out.println(admin1.getUserId());
	     AdminBean admin1;
		 admin1=checkLoginDetails(admin);
		 if(admin1!=null)
		 {

	if(role.equals("ADMIN")) 
	{
		System.out.println("entered");
		System.out.println("1.Add Users");
		System.out.println("2.Display user details");
		System.out.println("3.Delete users");
		System.out.println("4.Logout");
		System.out.println("Enter your choice");
		int choice=sc.nextInt();
		service=new AdminServiceImpl();
		switch(choice) {
		case 1:
			admin = new AdminBean();
			System.out.println("Enter user id:");
			String user=sc.next();
			admin.setUserId(user);
			System.out.println("Enter password:");
			String pass=sc.next();
			admin.setPassword(pass);
			System.out.println("Enter role:");
			String userRole=sc.next();
			admin.setRole(userRole);
			
			userStatus=service.addUser(admin);
			if(userStatus>0) {
				System.out.println(userStatus+"data inserted");
			}
			else {
				System.out.println("no data inserted");
			}
			
			break;
		case 2:
			userList=new ArrayList();
			userList=service.retriveAllUsers();
			for (AdminBean adminBean : userList) {
				System.out.println(adminBean);
			}
			break;
		case 3:
			System.out.println("Enter user id:");
			String user1=sc.next();
			deleteStatus=service.deleteUsers(user1);
			if(deleteStatus>0) {
				System.out.println(deleteStatus+"is deleted");
			}
			else {
				System.out.println("no data deleted");
			}
			break;
		case 4:
			System.out.println("Successfully logged out!!!!");
			//System.exit(0);
			break;
		}
		
	}//IF
	//*************************RMG**************************************************
	else if(role.equals("RMG")) {
		System.out.println("1.Get Project Details");
		System.out.println("2.Raise requisition in projects");
		System.out.println("3.View and Accept  the Employees");
		System.out.println("4.Reject the Employees");
		System.out.println("5.Get Reports based on Pending Requisition Status");
		System.out.println("6.Get Reports based on closed Requisition Status");
		System.out.println("Enter your choice");
		int choice1=sc.nextInt();
		switch(choice1) {
		case 1:
			rmService=new RmgServiceImpl();
			System.out.println("Enter your id:");
			String rid=sc.next();
			List<ProjectBean> plist=null;
			plist=rmService.getProjectDetails(rid);
			for (ProjectBean projectBean : plist) {
				System.out.println(projectBean);
			}
			
			break;
		case 2:
			int rmStatus=0;
			rbean=new RequisitionBean();
			rmService=new RmgServiceImpl();
			
			System.out.println("Enter Requisition Id:");
			String req=sc.next();
			rbean.setRequisitionId(req);
			System.out.println("Enter your id:");
			String rmid=sc.next();
			rbean.setRmId(rmid);
			System.out.println("Enter project id:");
			String prId=sc.next();
			rbean.setProjectId(prId);
			System.out.println("Enter vacancy name:");
			String vname=sc.next();
			rbean.setVacancyName(vname);
			System.out.println("Enter skill");
			String skill=sc.next();
			rbean.setSkill(skill);
			System.out.println("Enter domain:");
			String domain=sc.next();
			rbean.setDomain(domain);
			System.out.println("number of vacancies available:");
			int vacancy=sc.nextInt();
			rbean.setNumberRequired(vacancy);
			rmStatus=rmService.raiseRequisition(rbean);
			if(rmStatus>0) {
				System.out.println(rmStatus+"requisition raised");
			}
			else {
				System.out.println("unable to raise requisition");
			}
			
			
			break;
			
		case 3:
		rmService=new RmgServiceImpl();
		System.out.println("enter Requisition Id:");
		String reqId=sc.next();
		List<ReqEmployee> rempList= new ArrayList<>();
		rempList=rmService.retrieveDetails(reqId);
		System.out.println(rempList);
		for (ReqEmployee reqEmployee : rempList) {
			System.out.println(reqEmployee);
		}
		System.out.println("Enter employee id:");
		String eid=sc.next();
		boolean b=rmService.selectEmployee(eid,reqId);
		if(b==true) {
			System.out.println("selected");
		}
		else {
			System.out.println("not selected");
		}
		break;
		case 4:
			rmService=new RmgServiceImpl();
			System.out.println("enter Requisition Id:");
			String reqId1=sc.next();
			List<ReqEmployee> rempList1= new ArrayList<>();
			rempList1=rmService.retrieveDetails(reqId1);
			
			for (ReqEmployee reqEmployee : rempList1) {
				System.out.println(reqEmployee);
			}
			rmService=new RmgServiceImpl();
			System.out.println("Enter employee id:");
			String eid1=sc.next();
			boolean b2=rejectRes(eid1, reqId1);
			if(b2==true) {
				System.out.println("Employee rejected successfully");
			}
			else {
				System.out.println("Employee not rejected");
			}
			
			break;
		case 5:
			rmService=new RmgServiceImpl();
			System.out.println("Enter your id:");
			String rmid1=sc.next();
			List<RequisitionBean> rmstatus=null;
			 rmstatus=new ArrayList<RequisitionBean>();
			 System.out.println(rmstatus);
			 rmstatus=rmService.getRequisitionByStatus(rmid1);
		
				for (RequisitionBean requisitionBean : rmstatus) {
					System.out.println(requisitionBean);
			}
			
				
			 
			
			 break;
		case 6:
			rmService=new RmgServiceImpl();
			System.out.println("Enter your id:");
			String rmid2=sc.next();
			
			 List<RequisitionBean> rmstatus2=new ArrayList<RequisitionBean>();
			 rmstatus2=rmService.getRequisitionByStatusClosed(rmid2);
			 for (RequisitionBean requisitionBean : rmstatus2) {
				System.out.println(requisitionBean);
			}
			
			break;
			
			
		
			
		
		}
	}//else if
	//*************************RMGE**************************************************
	else if(role.equals("RMGE")) {
		System.out.println("1.Search employee based on requisition and assign to RMG");		
		System.out.println("2.Get requisitions irrespective of RMG");
		System.out.println("3. Show pending requisitions");
		System.out.println("4.Show closed requisitions");
		System.out.println("5. Logout");
		System.out.println("Enter any one option: ");
		int option = sc.nextInt();
		
		switch(option) {
		
		case 1:
			rmgeService=new RmgeServiceImpl();
			System.out.println("Enter resource manager Id");
			String rid=sc.next();
			rbean=new RequisitionBean();
			rbean=rmgeService.getParticularRequisition(rid);
			
			List<EmployeeBean>employeeList=new ArrayList<>();
			employeeList=rmgeService.getEmployeeDetails(rbean);
			for ( EmployeeBean employeeBean : employeeList) {
				System.out.println(employeeBean);
	              
			}
			int output = rmgeService.storeEmployeeDetails(employeeList, rbean);
			if(output > 0) {
				System.out.println("Successfully Inserted!!!!");
			}
			else {
				System.out.println("No matching employees found");
			}
			break;
			
		case 2:
			
			rmgeService=new RmgeServiceImpl();
			List<RequisitionBean> reqList=new ArrayList();
			reqList=rmgeService.getAllRequisition();
			for (RequisitionBean requisitionBean : reqList) {
				System.out.println(requisitionBean);
			}			
			
			break;
			
		case 3:
			rmgeService=new RmgeServiceImpl();
			System.out.println("enter resource manager id:");
			String rmid3=sc.next();
			 //System.out.println("Pending Requisitions: ");
			 List<RequisitionBean> preqList=new ArrayList();
				preqList=rmgeService.getPendingRequisition(rmid3);
				for (RequisitionBean prequisitionBean : preqList) 
				{
					System.out.println(prequisitionBean);
				}
				
				
				break;
		case 4:
			rmgeService=new RmgeServiceImpl();
			System.out.println("enter resource manager id:");
			String rmid4=sc.next();
			System.out.println("Closed Requisitions: ");
			 List<RequisitionBean> creqList=new ArrayList();
				creqList=rmgeService.getClosedRequisition(rmid4);
				for (RequisitionBean crequisitionBean : creqList) {
					System.out.println(crequisitionBean);
				}
				break;
		case 5:
			System.out.println("Successfully logged out");
			System.exit(0);
			}
			
		
			
		}
 }
	
	else
	{
		System.out.println("Invalid Login Credentials");
	}
	
}




private static AdminBean checkLoginDetails(AdminBean admin) throws IOException {
	ILoginService service = new LoginService();
	return service.checkUserDetails(admin);
}
private static boolean rejectRes(String empId, String reqId1) throws IOException {
	rmService=new RmgServiceImpl();
	boolean b=rmService.rejectRes(empId, reqId1);
	return b;
}


}
