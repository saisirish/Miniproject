package com.capgemini.irs.dao;

import java.io.IOException;
import java.security.GeneralSecurityException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.omg.Messaging.SyncScopeHelper;

import com.capegemini.irs.bean.EmployeeBean;
import com.capegemini.irs.bean.RequisitionBean;
import com.capgemini.irs.util.DbUtility;

public class RmgeDaoImpl implements RmgeDao {
Connection conn=null;
RequisitionBean rbean=null;

	@Override
	public RequisitionBean getParticularRequisition(String rid) throws IOException {
	conn=DbUtility.getConnect();
	try {
		PreparedStatement prepare=conn.prepareStatement(IQueryMapper.searchRequisition);
		prepare.setString(1, rid);
	ResultSet rs=prepare.executeQuery();
	while(rs.next()) {
		rbean=new RequisitionBean();
		rbean.setRequisitionId(rs.getString(1));
		rbean.setRmId(rs.getString(2));
		rbean.setProjectId(rs.getString(3));
		rbean.setStartDate(rs.getString(4));
		rbean.setClosingDate(rs.getString(5));
		rbean.setCurrentStatus(rs.getString(6));
		rbean.setVacancyName(rs.getString(7));
		rbean.setSkill(rs.getString(8));
		rbean.setDomain(rs.getString(9));
		rbean.setNumberRequired(rs.getInt(10));
	}
	} catch (SQLException e) {
		System.out.println("unable to fetch requisition details");
		
	}

		return rbean;
	}

	@Override
	public List<EmployeeBean> getEmployeeDetails(RequisitionBean rbean) throws IOException {
	conn=DbUtility.getConnect();
	List<EmployeeBean> empList=null;
	EmployeeBean empBean=null;
	
	try {
		PreparedStatement prepare1=conn.prepareStatement(IQueryMapper.searchEmployee);		
		String skill=rbean.getSkill();
		String domain=rbean.getDomain();		
		prepare1.setString(1, skill);
		prepare1.setString(2,domain);
		ResultSet rs1=prepare1.executeQuery();
		empList =new ArrayList<>();		
		
		while(rs1.next()) {
			
			empBean=new EmployeeBean();
			empBean.setEmployeeId(rs1.getString(1));
			empBean.setEmployeeName(rs1.getString(2));
			empBean.setProjectId(rs1.getString(3));
			empBean.setSkill(rs1.getString(4));
			empBean.setDomain(rs1.getString(5));
			empBean.setExperience(rs1.getInt(6));
			empList.add(empBean);
			
			
		}
	} catch (SQLException e) {
		System.out.println("unable to fetch employee details");
		
	}
		
		return empList;
	}

	@Override
	public List<RequisitionBean> getAllRequisition() throws IOException {
		conn=DbUtility.getConnect();
		List<RequisitionBean> reqList=null;
		RequisitionBean reqBean=null;
		try {
			PreparedStatement pst=conn.prepareStatement(IQueryMapper.showAllRequisitions);
			ResultSet rs=pst.executeQuery();
			
			reqList=new ArrayList<>();
			while(rs.next())
				{
				
				reqBean = new RequisitionBean(rs.getString(1), rs.getString(2),rs.getString(3), rs.getString(4), rs.getString(5), rs.getString(6), rs.getString(7), rs.getString(8),rs.getString(9),rs.getInt(10)); 
				reqList.add(reqBean);
				}
			
		} catch (SQLException e) {
			
			e.printStackTrace();
		}
		return reqList;
	}
	@Override
	public List<RequisitionBean> getPendingRequisition(String rmid3) throws IOException {
		conn=DbUtility.getConnect();
		List<RequisitionBean> preqList=null;
		RequisitionBean preqBean=null;
		try {
			preqList=new ArrayList<RequisitionBean>();
			PreparedStatement pst=conn.prepareStatement(IQueryMapper.showPendingRequisitions);
			pst.setString(1, rmid3);			
			ResultSet rs=pst.executeQuery();
			
			while(rs.next())
			{
				preqBean = new RequisitionBean(rs.getString(1), rs.getString(2),rs.getString(3), rs.getString(4), rs.getString(5), rs.getString(6), rs.getString(7), rs.getString(8),rs.getString(9),rs.getInt(10)); 
				preqList.add(preqBean);
			}
			
		} catch (SQLException e) {
			System.out.println("no matching requisitions found");
			e.printStackTrace();
		}
		
		return preqList;
	}

	@Override
	public List<RequisitionBean> getClosedRequisition(String rmid4) throws IOException
	{
		conn=DbUtility.getConnect();
		List<RequisitionBean> creqList=null;
		RequisitionBean creqBean=null;
		try {
			PreparedStatement pst=conn.prepareStatement(IQueryMapper.getRequisitionByStatusClosed2);
			pst.setString(1,rmid4);
			ResultSet rs=pst.executeQuery();
			creqList=new ArrayList<>();
			while(rs.next())
			{
				creqBean = new RequisitionBean(rs.getString(1), rs.getString(2),rs.getString(3), rs.getString(4), rs.getString(5), rs.getString(6), rs.getString(7), rs.getString(8),rs.getString(9),rs.getInt(10)); 
				creqList.add(creqBean);
			}
			
		} catch (SQLException e) {
			System.out.println("no matching requisitions found");
			e.printStackTrace();
		}
		return creqList;
	}

	@Override
	public int storeEmployeeDetails(List<EmployeeBean> employeeList, RequisitionBean rbean) throws IOException {
	
		int res = 0;
		for (EmployeeBean employeeBean : employeeList) {
			conn=DbUtility.getConnect();
			
			try {
				PreparedStatement pst = conn.prepareStatement(IQueryMapper.storeEmployeeDetails);
				pst.setString(1, rbean.getRequisitionId());
				pst.setString(2, employeeBean.getEmployeeId());
				pst.setString(3, employeeBean.getEmployeeName());
				pst.setString(4, employeeBean.getProjectId());
				pst.setString(5, employeeBean.getSkill());
				pst.setString(6, employeeBean.getDomain());
				pst.setInt(7, employeeBean.getExperience());
				res = pst.executeUpdate();
			
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		}
		return res;
	}

	

}
