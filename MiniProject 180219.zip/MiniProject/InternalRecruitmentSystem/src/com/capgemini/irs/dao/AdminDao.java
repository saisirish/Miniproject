package com.capgemini.irs.dao;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.capegemini.irs.bean.AdminBean;
import com.capgemini.irs.util.DbUtility;

public class AdminDao implements IAdminDao
{
Connection conn=null;
	@Override
	public int addUsers(AdminBean admin) throws IOException
	{
		conn=DbUtility.getConnect();
		int status=0;
		
		try {
			PreparedStatement prepare=conn.prepareStatement(IQueryMapper.addUsers);
			prepare.setString(1, admin.getUserId());
			prepare.setString(2, admin.getPassword());
			prepare.setString(3, admin.getRole());
			status=prepare.executeUpdate();
		} catch (SQLException e) {
			System.out.println("no data inserted");
			e.printStackTrace();
		}
		return status;
	}
	@Override
	public List<AdminBean> retriveAllUsers() throws IOException {
		conn=DbUtility.getConnect();
		List<AdminBean> userList=null;
		AdminBean admin=null;
		try {
			Statement st=conn.createStatement();
			ResultSet rs=st.executeQuery(IQueryMapper.retriveUsers);
			userList=new ArrayList();
			 
			while(rs.next()) {
				 
				admin=new AdminBean(rs.getString(1),rs.getString(2),rs.getString(3));
					
					 userList.add(admin);
					 
				 
			}
		} catch (SQLException e) {
			System.out.println("no data found");
			e.printStackTrace();
		}
		return userList;
	}
	@Override
	public int deleteUsers(String user1) throws IOException {
		int status1=0;
		conn=DbUtility.getConnect();
		try {
			PreparedStatement prepare=conn.prepareStatement(IQueryMapper.deleteUsers);
			prepare.setString(1, user1);
			status1=prepare.executeUpdate();
			
		} catch (SQLException e) {
			System.out.println("no data deleted");
			e.printStackTrace();
		}
		return status1;
	}

}
