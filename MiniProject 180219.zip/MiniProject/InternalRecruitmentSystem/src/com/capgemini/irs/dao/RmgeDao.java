package com.capgemini.irs.dao;

import java.io.IOException;
import java.util.List;

import com.capegemini.irs.bean.EmployeeBean;
import com.capegemini.irs.bean.RequisitionBean;

public interface RmgeDao {

	RequisitionBean getParticularRequisition(String rid) throws IOException;

	List<EmployeeBean> getEmployeeDetails(RequisitionBean rbean) throws IOException;

	List<RequisitionBean> getAllRequisition() throws IOException;

	List<RequisitionBean> getPendingRequisition(String rmid3) throws IOException;

	List<RequisitionBean> getClosedRequisition(String rmid4) throws IOException;

	int storeEmployeeDetails(List<EmployeeBean> employeeList, RequisitionBean rbean) throws IOException;

}
