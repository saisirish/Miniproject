package com.capgemini.irs.dao;

import java.io.IOException;
import java.util.List;

import com.capegemini.irs.bean.AdminBean;

public interface IAdminDao {

	int addUsers(AdminBean admin) throws IOException;

	List<AdminBean> retriveAllUsers() throws IOException;

	int deleteUsers(String user1) throws IOException;

}
