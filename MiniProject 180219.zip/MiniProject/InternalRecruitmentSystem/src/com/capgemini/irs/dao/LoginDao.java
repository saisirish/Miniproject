package com.capgemini.irs.dao;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.capegemini.irs.bean.AdminBean;
import com.capgemini.irs.util.DbUtility;

public class LoginDao implements ILoginDao{
	ResultSet rs = null;
	boolean b1;
	boolean b2;
	boolean b3;
	@Override
	public AdminBean checkUserDetails(AdminBean admin) throws IOException {
		Connection con = null;
		AdminBean admin1=null;
		
		con = DbUtility.getConnect();
		try {
			PreparedStatement pst = con.prepareStatement("Select *from users where user_id = ? and PASSWORD=?");
			pst.setString(1, admin.getUserId());
			pst.setString(2, admin.getPassword());
			 rs = pst.executeQuery();
			 
			if(rs.next()) {
				//rs.getString(1).equals(admin.getUserId()) ;
				//rs.getString(2).equals(admin.getPassword());
				//rs.getString(3).equals(admin.getRole());
				System.out.println("enterd inside dao"+rs.getString(1));
			admin1=new AdminBean(rs.getString(1),rs.getString(2), rs.getString(3));
				
			}//if
		} 
		catch (SQLException e) {
			System.out.println("Exception: " + e.getMessage());		}
		return admin1;
		
	}

}
