package com.capgemini.irs.dao;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.capegemini.irs.bean.ProjectBean;
import com.capegemini.irs.bean.ReqEmployee;
import com.capegemini.irs.bean.RequisitionBean;
import com.capgemini.irs.util.DbUtility;

public class RmgDaoImpl implements IRmgDao {
	Connection conn=null;
	@Override
	public int raiseRequisition(RequisitionBean rbean1) throws IOException {
		conn=DbUtility.getConnect();
		int status2=0;
		
		try {
			PreparedStatement prepare=conn.prepareStatement(IQueryMapper.raiseRequisition);
			prepare.setString(1,rbean1.getRequisitionId() );
			prepare.setString(2,rbean1.getRmId() );
			prepare.setString(3,rbean1.getProjectId() );
			prepare.setString(4,rbean1.getVacancyName() );
			prepare.setString(5,rbean1.getSkill());
			prepare.setString(6,rbean1.getDomain() );
			prepare.setInt(7,rbean1.getNumberRequired() );
			status2=prepare.executeUpdate();
		} catch (SQLException e) {
			System.out.println("no data inserted");
			e.printStackTrace();
		}
		return status2;
	}
	@Override
	public List<ReqEmployee> retrieveDetails(String reqId) throws IOException 
	{
		conn=DbUtility.getConnect();
		List<ReqEmployee> empList=null;
		PreparedStatement pst;
		try {
			pst = conn.prepareStatement(IQueryMapper.retrieveDetails);
			pst.setString(1,reqId);
			ResultSet rs=pst.executeQuery();
			empList=new ArrayList<>();
			ReqEmployee bean=null;
			while(rs.next())
			{
				bean=new ReqEmployee(rs.getString(1),rs.getString(2),rs.getString(3),rs.getString(4),rs.getString(5),rs.getString(6),rs.getInt(7));
				empList.add(bean);
			}
		} catch (SQLException e) {
			
			e.printStackTrace();
		}
		
		return empList;
	}
	@Override
	public boolean getEmployeeDetails(String eid, String reqId) throws IOException {
		boolean result2=false;;
	
		conn=DbUtility.getConnect();
		PreparedStatement pst=null;
		try {
			pst=conn.prepareStatement(IQueryMapper.getrequisition);
			pst.setString(1, reqId);
			ResultSet rs=pst.executeQuery();
			if(rs.next()) {
				int availableVacancies=rs.getInt(10);
				String proId=rs.getString(3);
				System.out.println("Available vacancies:"+availableVacancies);
				System.out.println("Project id is:"+proId);
				if(availableVacancies>0) {
					 result2=updateEmpProjId(eid,proId);
				}
			
				if(result2) {
				--availableVacancies;
				pst=conn.prepareStatement(IQueryMapper.updateVacancies);
				pst.setInt(1,availableVacancies );
				pst.setString(2, reqId);
				int status3=pst.executeUpdate();
				if(status3!=0) {
					if(availableVacancies==0) {
					
						pst=conn.prepareStatement(IQueryMapper.updateRequisionStatus);
						pst.setString(1, reqId);
						int status4=pst.executeUpdate();
						if(status4>0) {
							System.out.println("requistion closed");
						}
						else {
							System.out.println("requistion pending");
						}
					}
					else {
						System.out.println("vacancies available");
					}
				}
				else {
					System.out.println("vacancies are not updated");
				}
			}
				result2=true;
		} 
			else {
				System.out.println("no data available");
			}
		}catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return result2;
	}
	private boolean updateEmpProjId(String eid, String proId) throws IOException {
		conn=DbUtility.getConnect();
		int status6=0;
		try {
			PreparedStatement pst=conn.prepareStatement(IQueryMapper.updateprojectid);
			pst.setString(1, proId);
			pst.setString(2, eid);
			 status6=pst.executeUpdate();
		
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		if(status6>0) {
			return true;
		}
		else {
			return false;
		}
		
		
	}
	public boolean rejectRes(String empId,String reqId1) throws IOException  {

		

		boolean result = false;

		result = updateEmpProjId(empId,"rmg");

		return result;

	}
	@Override
	public List<ProjectBean> getProjectDetails(String rid) throws IOException {
		conn=DbUtility.getConnect();
		ProjectBean pbean=null;
		List<ProjectBean> plist=null;
		try {
			PreparedStatement pst4=conn.prepareStatement(IQueryMapper.getProjectDetails);
			pst4.setString(1, rid);
			ResultSet rs=pst4.executeQuery();
			plist=new ArrayList<ProjectBean>();
			while(rs.next()) {
				pbean=new ProjectBean(rs.getString(1), rs.getString(2), rs.getString(3), rs.getString(4), rs.getString(5), rs.getString(6));
				plist.add(pbean);
			}
		} catch (SQLException e) {
			System.out.println("no projects found");
			
			e.printStackTrace();
		}
		return plist;
	}
	@Override
	public List<RequisitionBean> getRequisitionByStatus(String rmid1) throws IOException {
		conn=DbUtility.getConnect();
		List<RequisitionBean> rlist1=null;
		try {
			PreparedStatement pst5=conn.prepareStatement(IQueryMapper.getRequisitionByStatus);
			pst5.setString(1, rmid1);
			
			
			
			ResultSet rs=pst5.executeQuery();
			rlist1=new ArrayList<RequisitionBean>();
			RequisitionBean rbean1=null;
			while(rs.next()) {
		
				
		rbean1=new RequisitionBean(rs.getString(1), rs.getString(2), rs.getString(3), rs.getString(4), rs.getString(5), rs.getString(6), rs.getString(7), rs.getString(8), rs.getString(9), rs.getInt(10));
		rlist1.add(rbean1);
			}
		} catch (SQLException e) {
			System.out.println("no matching requisitions");
			e.printStackTrace();
		}
		return rlist1;
	}
	@Override
	public List<RequisitionBean> getRequisitionByStatusClosed(String rmid2) throws IOException {
		conn=DbUtility.getConnect();
		List<RequisitionBean> rlist2=null;
		try {
			PreparedStatement pst5=conn.prepareStatement(IQueryMapper.getRequisitionByStatusClosed);
			pst5.setString(1, rmid2);
			
			
			
			ResultSet rs=pst5.executeQuery();
			rlist2=new ArrayList<RequisitionBean>();
			RequisitionBean rbean1=null;
			while(rs.next()) {
		
				
		rbean1=new RequisitionBean(rs.getString(1), rs.getString(2), rs.getString(3), rs.getString(4), rs.getString(5), rs.getString(6), rs.getString(7), rs.getString(8), rs.getString(9), rs.getInt(10));
		rlist2.add(rbean1);
			}
		} catch (SQLException e) {
			System.out.println("no closed requisitions");
			e.printStackTrace();
		}
		return rlist2;
		
	}
	

}
