package com.capgemini.irs.dao;

import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

import com.capegemini.irs.bean.ProjectBean;
import com.capegemini.irs.bean.ReqEmployee;
import com.capegemini.irs.bean.RequisitionBean;

public interface IRmgDao {

	int raiseRequisition(RequisitionBean rbean) throws IOException;

	List<ReqEmployee> retrieveDetails(String reqId) throws IOException;

	boolean getEmployeeDetails(String eid, String reqId) throws IOException;
	public boolean rejectRes(String empId,String reqId1) throws IOException;

	List<ProjectBean> getProjectDetails(String rid) throws IOException;

	List<RequisitionBean> getRequisitionByStatus(String rmid1) throws IOException;

	List<RequisitionBean> getRequisitionByStatusClosed(String rmid2) throws IOException;
}
