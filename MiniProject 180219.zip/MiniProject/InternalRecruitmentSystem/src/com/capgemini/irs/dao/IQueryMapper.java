package com.capgemini.irs.dao;
//admin
public interface IQueryMapper {
public static final String addUsers="INSERT INTO users VALUES(?,?,?)";
public static final String retriveUsers="SELECT * FROM users";
public static final String deleteUsers="DELETE FROM users WHERE user_id=?";

//rmg
public static final String  getProjectDetails="SELECT * FROM project WHERE RM_ID=?";
public static final String raiseRequisition="INSERT INTO requisition VALUES(?,?,?,SYSDATE,SYSDATE,'pending',?,?,?,?)";
public static final String getrequisition="SELECT * FROM requisition WHERE REQUISITION_ID=?";
public static final String  updateVacancies="UPDATE REQUISITION SET NUMBER_REQUIRED=? WHERE  REQUISITION_ID=?";
public static final String  updateRequisionStatus="UPDATE REQUISITION SET CURRENT_STATUS='closed', DATE_CLOSED=SYSDATE  WHERE  REQUISITION_ID=?";
public static final String  updateprojectid="UPDATE employee2 SET PROJECT_ID=? WHERE EMPLOYEE_ID=?";
public static final String  getRequisitionByStatus="SELECT * FROM requisition WHERE RM_ID=? and CURRENT_STATUS='pending'";
public static final String  getRequisitionByStatusClosed="SELECT * FROM requisition WHERE RM_ID=? and CURRENT_STATUS='closed'";
public static final String retrieveDetails = "SELECT * from REQEMPLOYEE where REQ_ID=?";


//rmge
public static final String searchRequisition="SELECT * FROM requisition WHERE rm_id=?";
public static final String searchEmployee="SELECT * FROM EMPLOYEE2 WHERE SKILL=? and DOMAIN=? and PROJECT_ID='rmg'";
public static final String showAllRequisitions = "SELECT * from requisition ";
public static final String  getRequisitionByStatusClosed2="SELECT * FROM requisition WHERE RM_ID=? and CURRENT_STATUS='closed'";
public static final String showPendingRequisitions = "SELECT * from requisition WHERE RM_ID=? and CURRENT_STATUS='pending'";
public static final String storeEmployeeDetails = "INSERT INTO REQEMPLOYEE VALUES(?,?,?,?,?,?,?)";

 

}
